package com.JimLi.ncmodmaker;

import android.content.Context;
import android.util.Log;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;

public class FileUtils {

    public static boolean fileCopy(String oldFilePath, String newFilePath) throws IOException {

        if (!fileExists(oldFilePath)) {
            return false;
        }

        FileInputStream inputStream = new FileInputStream(new File(oldFilePath));
        byte[] data = new byte[1024];

        FileOutputStream outputStream = new FileOutputStream(new File(newFilePath));

        while (inputStream.read(data) != -1) {
            outputStream.write(data);
        }
        inputStream.close();
        outputStream.close();
        return true;
    }

    public static boolean fileExists(String filePath) {
        File file = new File(filePath);
        return file.exists();
    }
    public static boolean writeTXT(String data, File filepath){
        try {
            FileOutputStream f = new FileOutputStream(filepath);
            PrintWriter pw = new PrintWriter(f);
            pw.println(data);
            pw.flush();
            pw.close();
            f.close();
        }
        catch (IOException e) {
            Log.e("Exception", "File write failed: " + e.toString());
            return false;
        }
        return true;
    }
}
