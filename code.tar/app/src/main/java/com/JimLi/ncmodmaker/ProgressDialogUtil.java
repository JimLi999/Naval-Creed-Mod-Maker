package com.JimLi.ncmodmaker;

import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;

public class ProgressDialogUtil {
    private static AlertDialog alertDialog;

    public static void show(Context context){
        if(alertDialog==null){
            alertDialog = new AlertDialog.Builder(context,R.style.CustomProgressDialog).create();
        }
        View v= LayoutInflater.from(context).inflate(R.layout.loading,null);
        alertDialog.setView(v,0,0,0,0);
        alertDialog.setCanceledOnTouchOutside(false);

        alertDialog.show();
    }
    public static void dismiss(){
        if(alertDialog!=null&&alertDialog.isShowing()){
            alertDialog.dismiss();
        }
    }
}
